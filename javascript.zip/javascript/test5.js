// Expected Result : 6
// Direction : Get the total of "1" in binary value of number input
const number = 221;

function result(num) {
  // Your Code Here
  count = 0;
  const temp = (num >>> 0).toString(2);
  for(var i = 0; i< temp.length; i++){
    if(temp[i] === "1"){
      count++;
    }
  }
  return count;
}

console.log(result(number));