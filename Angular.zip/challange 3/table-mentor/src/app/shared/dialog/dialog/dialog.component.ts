import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {
  fg!: FormGroup;

  constructor(public dialogRef: MatDialogRef<DialogComponent>,@Inject(MAT_DIALOG_DATA) public data: any, private apiSrv: ApiService, private fb: FormBuilder) { 
    
  }

  ngOnInit(): void {
    this.initForm();
  }

  initForm(){
    this.fg = this.fb.group({
      email: [null, [Validators.required, Validators.email]],
      first_name: [null, [Validators.required]],
      last_name: [null, [Validators.required]],
    });
  }

  noClick(){
      this.dialogRef.close();
  }


  getErrorMessage() {
    if (this.fg.controls.email.hasError('required')
      && this.fg.controls.first_name.hasError('required')
      && this.fg.controls.last_name.hasError('required') ) {
      return 'You must enter a value';
    }

    console.log(this.fg.value.email);

    return this.fg.controls.email.hasError('email') ? 'Not a valid email' : '';
  }

  add(){
    console.log(this.fg.controls.email);

  }

  delete(){
    // this.apiSrv.deleteMentor(this.data).subscribe(result=>{
    //   console.log(result);
    // })
    this.apiSrv.getDataMentor().subscribe(result=>{
      const newData =  result.filter(data=> data._id !== this.data.id);
      this.dialogRef.close(newData);
    })

  }

}
